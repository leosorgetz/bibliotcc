<?php declare(strict_types = 1);

namespace Application\Migrations;

use Doctrine\DBAL\Migrations\AbstractMigration;
use Doctrine\DBAL\Schema\Schema;

/**
 * Auto-generated Migration: Please modify to your needs!
 */
class Version20180330195639 extends AbstractMigration
{
    public function up(Schema $schema)
    {
        // this up() migration is auto-generated, please modify it to your needs
        $this->abortIf($this->connection->getDatabasePlatform()->getName() !== 'mysql', 'Migration can only be executed safely on \'mysql\'.');

        $this->addSql('DROP INDEX UNIQ_2FB3D0EECB944F1A ON project');
        $this->addSql('ALTER TABLE project ADD student INT NOT NULL, ADD advisor INT NOT NULL, ADD evaluator_one INT NOT NULL, ADD evaluator_two INT NOT NULL, DROP student_id, DROP advisor_id, DROP evaluator_one_id, DROP evaluator_two_id');
        $this->addSql('CREATE UNIQUE INDEX UNIQ_2FB3D0EEB723AF33 ON project (student)');
    }

    public function down(Schema $schema)
    {
        // this down() migration is auto-generated, please modify it to your needs
        $this->abortIf($this->connection->getDatabasePlatform()->getName() !== 'mysql', 'Migration can only be executed safely on \'mysql\'.');

        $this->addSql('DROP INDEX UNIQ_2FB3D0EEB723AF33 ON project');
        $this->addSql('ALTER TABLE project ADD student_id INT DEFAULT NULL, ADD advisor_id INT DEFAULT NULL, ADD evaluator_one_id INT DEFAULT NULL, ADD evaluator_two_id INT DEFAULT NULL, DROP student, DROP advisor, DROP evaluator_one, DROP evaluator_two');
        $this->addSql('CREATE UNIQUE INDEX UNIQ_2FB3D0EECB944F1A ON project (student_id)');
    }
}
