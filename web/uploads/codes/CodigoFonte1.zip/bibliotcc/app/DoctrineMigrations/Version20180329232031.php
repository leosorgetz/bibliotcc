<?php declare(strict_types = 1);

namespace Application\Migrations;

use Doctrine\DBAL\Migrations\AbstractMigration;
use Doctrine\DBAL\Schema\Schema;

/**
 * Auto-generated Migration: Please modify to your needs!
 */
class Version20180329232031 extends AbstractMigration
{
    public function up(Schema $schema)
    {
        // this up() migration is auto-generated, please modify it to your needs
        $this->abortIf($this->connection->getDatabasePlatform()->getName() !== 'mysql', 'Migration can only be executed safely on \'mysql\'.');

        $this->addSql('CREATE TABLE project (id INT AUTO_INCREMENT NOT NULL, student_id INT DEFAULT NULL, advisor_id INT DEFAULT NULL, evaluator_one_id INT DEFAULT NULL, evaluator_two_id INT DEFAULT NULL, projectName VARCHAR(500) NOT NULL, projectDescription LONGTEXT NOT NULL, advisorGrade DOUBLE PRECISION DEFAULT NULL, evaluatorOneGrade DOUBLE PRECISION DEFAULT NULL, evaluatorTwoGrade DOUBLE PRECISION DEFAULT NULL, advisorConsiderations LONGTEXT DEFAULT NULL, evaluatorOneConsiderations LONGTEXT DEFAULT NULL, evaluatorTwoConsiderations LONGTEXT DEFAULT NULL, finalGrade DOUBLE PRECISION DEFAULT NULL, localPath VARCHAR(255) DEFAULT NULL, UNIQUE INDEX UNIQ_2FB3D0EECB944F1A (student_id), UNIQUE INDEX UNIQ_2FB3D0EE66D3AD77 (advisor_id), UNIQUE INDEX UNIQ_2FB3D0EE2EE5ACE8 (evaluator_one_id), UNIQUE INDEX UNIQ_2FB3D0EE45B94B27 (evaluator_two_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8 COLLATE utf8_unicode_ci ENGINE = InnoDB');
        $this->addSql('ALTER TABLE project ADD CONSTRAINT FK_2FB3D0EECB944F1A FOREIGN KEY (student_id) REFERENCES `user` (id)');
        $this->addSql('ALTER TABLE project ADD CONSTRAINT FK_2FB3D0EE66D3AD77 FOREIGN KEY (advisor_id) REFERENCES `user` (id)');
        $this->addSql('ALTER TABLE project ADD CONSTRAINT FK_2FB3D0EE2EE5ACE8 FOREIGN KEY (evaluator_one_id) REFERENCES `user` (id)');
        $this->addSql('ALTER TABLE project ADD CONSTRAINT FK_2FB3D0EE45B94B27 FOREIGN KEY (evaluator_two_id) REFERENCES `user` (id)');
    }

    public function down(Schema $schema)
    {
        // this down() migration is auto-generated, please modify it to your needs
        $this->abortIf($this->connection->getDatabasePlatform()->getName() !== 'mysql', 'Migration can only be executed safely on \'mysql\'.');

        $this->addSql('DROP TABLE project');
    }
}
