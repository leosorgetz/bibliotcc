<?php

namespace AppBundle\Controller;

use AppBundle\Entity\Project;
use AppBundle\Entity\User;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Method;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Security;
use Symfony\Component\Security\Core\Exception\AccessDeniedException;

/**
 * Project controller.
 *
 * @Route("project")
 */
class ProjectController extends Controller
{
    /**
     * Lists all project entities.
     *
     * @Route("/", name="project_index")
     * @Method("GET")
     */
    public function indexAction()
    {
        $em = $this->getDoctrine()->getManager();

        $boards = $em->getRepository('AppBundle:Project')->findByBoardFinalizedAndGrade();

        return $this->render('project/index.html.twig', array(
            'boards' => $boards,
        ));
    }

    /**
     * Finds and displays a project entity.
     *
     * @Route("/{id}", name="project_show")
     * @Method("GET")
     */
    public function showAction(Project $project)
    {
        return $this->render('project/show.html.twig', array(
            'project' => $project,
        ));
    }

    /**
     * Displays a form to edit an existing project entity.
     *
     * @Route("/{id}/edit", name="project_edit")
     * @Method({"GET", "POST"})
     * @Security("has_role('ROLE_ADMIN')")
     */
    public function editAction(Request $request, Project $project)
    {
        $editForm = $this->createForm('AppBundle\Form\ProjectType', $project);

        $editForm->handleRequest($request);

        if ($editForm->isSubmitted() && $editForm->isValid()) {
            if (!is_null($project->getLocalPath())) {
                $file = $project->getLocalPath();

                $fileName = $this->generateUniqueFileName() . '.' . $file->guessExtension();

                $file->move(
                    $this->getParameter('projects_directory'),
                    $fileName
                );

                $project->setLocalPath($fileName);
            }

            $this->getDoctrine()->getManager()->flush();
            return $this->redirectToRoute('project_edit', array('id' => $project->getId()));
        }

        return $this->render('project/edit.html.twig', array(
            'project' => $project,
            'edit_form' => $editForm->createView(),
        ));
    }

    /**
     * @Route("/first-post/{id}", name="project_first_post")
     * @Method({"GET", "POST"})
     * @Security("has_role('ROLE_STUDENT')")
     */
    public function firstPostAction(Request $request, Project $project)
    {
        // Caso não seja o usuario responsavel pelo projeto.
        if ($project->getStudent()->getId() != $this->getUser()->getId()) {
            throw $this->createAccessDeniedException();
        }

        // Caso tenha passado da data inicial.
        if (date('Y-m-d H:i', strtotime('now')) > date('Y-m-d H:i', $project->getFirstPostDate()->getTimestamp())) {
            throw $this->createAccessDeniedException();
        }

        $form = $this->createForm('AppBundle\Form\ProjectType', $project);
        $form->remove('student');
        $form->remove('advisor');

        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            if (!is_null($project->getLocalPath())) {
                $file = $project->getLocalPath();

                $fileName = $this->generateUniqueFileName() . '.' . $file->guessExtension();

                $file->move(
                    $this->getParameter('projects_directory'),
                    $fileName
                );

                $project->setLocalPath($fileName);
            }

            $project->setFirstPost(true);
            $this->getDoctrine()->getManager()->flush();
            return $this->redirectToRoute('board_show', array('id' => $project->getBoard()->getId()));
        }

        return $this->render('project/first-post.html.twig', array(
            'project' => $project,
            'form' => $form->createView(),
        ));
    }

    /**
     * @Route("/last-post/{id}", name="project_last_post")
     * @Method({"GET", "POST"})
     * @Security("has_role('ROLE_STUDENT')")
     */
    public function secondPostAction(Request $request, Project $project)
    {
        // Caso não seja o usuario responsavel pelo projeto.
        if ($project->getStudent()->getId() != $this->getUser()->getId()) {
            throw $this->createAccessDeniedException('Você não é responsavel por este projeto.');
        }

        // Caso não tenha feito a primeira postagem.
        if (!$project->getFirstPost()) {
            throw $this->createAccessDeniedException('Não foi realizado uma primeira postagem.');
        }

        // Caso não tenha sido apresentada.
        if (!$project->getBoard()->getIsPresented()) {
            throw $this->createAccessDeniedException('A banca ainda não foi apresentada.');
        }

        // Caso tenha passado a data final de entrega.
        if (date('Y-m-d H:s', strtotime('now')) > date('Y-m-d H:s', $project->getLastPostDate()->getTimestamp())) {
            throw $this->createAccessDeniedException('A data final de entrega já passou.');
        }

        $form = $this->createForm('AppBundle\Form\ProjectType', $project);
        $form->remove('student');
        $form->remove('advisor');

        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            if (!is_null($project->getLocalPath())) {
                $file = $project->getLocalPath();

                $fileName = $this->generateUniqueFileName() . '.' . $file->guessExtension();

                $file->move(
                    $this->getParameter('projects_directory'),
                    $fileName
                );

                $project->setLocalPath($fileName);
            }
            $project->setLastPost(true);
            $this->getDoctrine()->getManager()->flush();
            return $this->redirectToRoute('project_show', array('id' => $project->getId()));
        }

        return $this->render('project/last-post.html.twig', array(
            'project' => $project,
            'form' => $form->createView(),
        ));
    }

    /**
     * Download file by POST.
     * @Route("/download/{id}", name="project_download")
     * @Method({"POST"})
     */
    public function downloadFileAction(Project $project)
    {
        $path = $this->getParameter('projects_directory') . '/' . $project->getLocalPath();
        header('Content-Description: File Transfer');
        header('Content-Type: application/octet-stream');
        header('Content-Disposition: attachment; filename="' . basename($path) . '"');
        header('Expires: 0');
        header('Cache-Control: must-revalidate');
        header('Pragma: public');
        flush();
        readfile($path);
    }

    /**
     * Creates a form to delete a project entity.
     *
     * @param Project $project The project entity
     *
     * @return \Symfony\Component\Form\FormInterface
     */
    private function createDeleteForm(Project $project)
    {
        return $this->createFormBuilder()
            ->setAction($this->generateUrl('project_delete', array('id' => $project->getId())))
            ->setMethod('DELETE')
            ->getForm();
    }

    /**
     * @return string
     */
    private function generateUniqueFileName()
    {
        return md5(uniqid());
    }

}
